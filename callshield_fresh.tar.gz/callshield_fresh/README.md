# CallShield

A React Native app for call protection and scam detection built with Expo.

## Project Structure

```
CallShield/
├── app/                    # App screens (using Expo Router)
│   ├── _layout.js         # Root layout with tab navigation
│   ├── index.js           # Home screen with power button
│   ├── data.js            # Call history screen
│   └── permissions.js     # Permissions screen
├── constants/
│   └── theme.js           # Colors, spacing, fonts
├── assets/
│   └── images/
│       ├── icon.png       # App icon
│       └── splash.png     # Splash screen
├── app.json               # Expo configuration
├── package.json           # Dependencies
└── babel.config.js        # Babel configuration
```

## Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Start the App

For Android Emulator:
```bash
npx expo start --android
```

For iOS Simulator (Mac only):
```bash
npx expo start --ios
```

For Web Browser:
```bash
npx expo start --web
```

Or just scan the QR code with Expo Go app:
```bash
npx expo start
```

## Team Responsibilities

- **Person 1**: React Native screens, widgets, notifications
- **Person 2**: FastAPI backend, Whisper transcription, SQLite, FFT analysis
- **Person 3**: Claude API integration, prompt engineering, model training

## Backend API

The frontend expects a FastAPI backend at `http://localhost:8000` with a `/ping` endpoint for connection testing.

## Next Steps

- [ ] Step 1: Verify backend connectivity with `/ping` endpoint
- [ ] Step 2: Add permissions screens
- [ ] Step 3: Integrate Whisper transcription
- [ ] Step 4: Add Claude API for call classification
- [ ] Step 5: Build call history UI
- [ ] Step 6: Add notifications system
- [ ] Step 7: Implement settings and accessibility
- [ ] Step 8: Polish and testing
